module.exports = {
  bindings: {},
  log: {
    info: jest.fn(),
    error: jest.fn()
  },
  done: jest.fn()
}
