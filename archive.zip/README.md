# ffc-demo-calculation-function
Azure function version of https://github.com/DEFRA/ffc-demo-calculation-service
