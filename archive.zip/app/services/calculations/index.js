const gross = require('./gross')
const net1 = require('./net1')
const net2 = require('./net2')

module.exports = {
  gross,
  net1,
  net2
}
